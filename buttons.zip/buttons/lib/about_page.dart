import 'package:flutter/material.dart';
import 'page_template.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PageTemplate(
      title: 'About',
      description: 'I am a student of ace engineering college as a data science student i am  very good at acedmics.',
    );
  }
}
