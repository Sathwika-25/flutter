import 'package:flutter/material.dart';
import 'home_page.dart';
import 'about_page.dart';
import 'achievements_page.dart';
import 'contact_page.dart';

class NavigationRow extends StatelessWidget {
  final BuildContext context;

  const NavigationRow(this.context, {super.key});

  void navigateTo(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        ElevatedButton(onPressed: () => navigateTo(HomePage()), child: Text('Home')),
        ElevatedButton(onPressed: () => navigateTo(AboutPage()), child: Text('About')),
        ElevatedButton(onPressed: () => navigateTo(AchievementsPage()), child: Text('Achievements')),
        ElevatedButton(onPressed: () => navigateTo(ContactPage()), child: Text('Contact')),
      ],
    );
  }
}
