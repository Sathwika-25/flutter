import 'package:flutter/material.dart';
import 'page_template.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PageTemplate(
      title: 'Home',
      description: 'Welcome This is CHERALA SATHWIKA '
          'know me more.',
    );
  }
}
