import 'package:flutter/material.dart';
import 'page_template.dart';

class AchievementsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PageTemplate(
      title: 'Achievements',
      description: 'As a BTech students have Achievement 30+ certifications!',
    );
  }
}
