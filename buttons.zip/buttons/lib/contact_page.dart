import 'package:flutter/material.dart';
import 'page_template.dart';

class ContactPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PageTemplate(
      title: 'Contact',
      description: 'Contacts :'
          'mobile : 9234671650'
          'email : student@gamil.com',

    );
  }
}
