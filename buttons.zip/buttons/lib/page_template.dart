import 'package:flutter/material.dart';
import 'navigation_row.dart';

class PageTemplate extends StatelessWidget {
  final String title;
  final String description;

  const PageTemplate({
    required this.title,
    required this.description,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context), // Pop for <---Details
        ),
        title: Text('$title Page'),
      ),
      body: Column(
        children: [
          NavigationRow(context), // Row with Home, About, Achievements, Contact
          Expanded(
            child: Center(
              child: Text(
                description,
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
